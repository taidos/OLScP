#!/bin/bash
tmpfile="$(mktemp -p /tmp custom-script-data-XXXXXXXX)"
cat "${1:-/dev/stdin}" > $tmpfile
USER=$(python -c "import sys, json; print json.load(open('$tmpfile'))['data']['user']")
DOMAIN=$(python -c "import sys, json; print json.load(open('$tmpfile'))['data']['domain']")
/usr/local/olscp/olscp create $DOMAIN $USER
