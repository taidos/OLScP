#!/bin/bash
tmpfile="$(mktemp -p /tmp custom-script-data-XXXXXXXX)"
cat "${1:-/dev/stdin}" > $tmpfile
DOMAIN=$(python -c "import sys, json; print json.load(open('$tmpfile'))['data']['args'] ['vhost-0']")
#PHP=$(python -c "import sys, json; print json.load(open('$tmpfile'))['data']['args'] ['version']")
PHP=$(python -c "import sys, json; print json.load(open('$tmpfile'))['data']['args'] ['version']" | cut -c 4-)
#OLDERPHP=$(cat /usr/local/lsws/conf/vhosts/$DOMAIN.conf | grep lsphp |head -1 | cut -f2- -d: | cut -c -7)
MAINPHP=(ls$PHP);
/usr/local/olscp/olscp php $DOMAIN $MAINPHP
#sed -i 's/$OLDERPHP/$MAINPHP/' /usr/local/lsws/conf/vhosts/$DOMAIN.conf
#echo "$OLDERPHP" > ~/php
#echo "$MAINPHP" > ~/php
#echo "$DOMAIN" > ~/php
